const BookModel1 = require("../models/bookModel")
const AuthorModel1=require("../models/authorModel")

let createAuthor= async function(req, res) {
    let data= req.body
    let saveData= await AuthorModel1.create(data)
    res.send({msg:saveData})
}

let createBook=async function(req, res) {
    let data=req.body
    let saveData= await BookModel1.create(data)
    res.send({msg:saveData})
}

    const listBooksByChetanBhagat=async function (_req,res) {
        let books= await AuthorModel1.find({author_name: "Chetan Bhagat"}).select("author_id")
        let allBooks =await BookModel1.find({author_id:data[0].author_id})
        res.send({msg:allBooks})
    }

    let authorOfBook=async function(_req,res) {
        let data=await BookModel1.findOneAndUpdate({name:"Two states"},{$set:{prices:100}},{new:true})
        let authorData=await AuthorModel1.find({author_id:data.author_id}).select("author_name")
        
        res.send({msg:authorData})
    }
     





// CRUD OPERATIONS:
// CREATE
// READ
// UPDATE
// DELETE



module.exports.createBook= createBook
module.exports.getBooksData= getBooksData
module.exports.updateBooks= updateBooks
module.exports.deleteBooks= deleteBooks
